package edu.ucsc.cse118.assignment2

class WorkspaceAdapter(private val workspaces: List<Workspace>) : RecyclerView.Adapter<WorkspaceAdapter.WorkspaceViewHolder>() {

    class WorkspaceViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val textView: TextView = view.findViewById(R.id.textView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WorkspaceViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.workspace_item, parent, false)
        return WorkspaceViewHolder(view)
    }

    override fun onBindViewHolder(holder: WorkspaceViewHolder, position: Int) {
        holder.textView.text = workspaces[position].name
    }

    override fun getItemCount(): Int {
        return workspaces.size
    }
}

