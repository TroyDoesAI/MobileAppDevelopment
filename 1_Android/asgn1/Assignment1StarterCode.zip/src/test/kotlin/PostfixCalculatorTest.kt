/*
#######################################################################
#
# Copyright (C) 2022-2023 David C. Harrison. All right reserved.
#
# You may not use, distribute, publish, or modify this code without
# the express written permission of the copyright holder.
#
#######################################################################
*/

import org.junit.jupiter.api.Test
import kotlin.test.fail

class PostfixCalculatorTest {
  @Test
  internal fun `write some real tests`() {
    fail("Is said write some real tests!")
  }
}